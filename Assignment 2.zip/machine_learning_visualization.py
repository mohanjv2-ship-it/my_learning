import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import  StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("student_mat.csv")

#used the below code to find the right target based on correlation of dataset.
dfa = df.corr(numeric_only=True)["G1"].sort_values(ascending=False)
print(dfa)

x = df.drop(["G2", "G3", "school", "address", "famsize"], axis=1)
y = df["G2"]

cat_col = x.select_dtypes(include= ["object", "bool"]).columns
num_col = x.select_dtypes(include= ["int", "float"]).columns

x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2, random_state=0)

# I have done imputing, scaling and encoding after training the data for a change

simple = SimpleImputer(strategy="mean")
x_train[num_col] = simple.fit_transform(x_train[num_col])
x_test[num_col] = simple.transform(x_test[num_col])

scale = StandardScaler()
x_train[num_col] = scale.fit_transform(x_train[num_col])
x_test[num_col] = scale.transform(x_test[num_col])

x_train_num = pd.DataFrame(x_train[num_col], columns=num_col)
x_test_num = pd.DataFrame(x_test[num_col], columns=num_col)

encode = OneHotEncoder(sparse_output=False)
x_train_cat = encode.fit_transform(x_train[cat_col])
x_test_cat = encode.transform(x_test[cat_col])
col_names = encode.get_feature_names_out() # have used .index to retain the index position to avoid NAN/null values
x_one = pd.DataFrame(x_train_cat, columns = col_names, index=x_train.index)
x_two = pd.DataFrame(x_test_cat, columns= col_names, index=x_test.index)
x_train_final = pd.concat([x_one, x_train_num], axis=1)
x_test_final = pd.concat([x_two, x_test_num], axis=1)

line = LinearRegression()
model = line.fit(x_train_final,y_train)
y_pred = model.predict(x_test_final)
print(y_pred)

r2 = ("R2_score:", r2_score(y_test, y_pred))
print(r2)

#as the program is regressor type program I have created a new column "pass" and fitted 0,1(for pass, fail)
df["pass"] = (df["G2"] >= 10).astype(int)

df["pass"].value_counts().plot.pie(labels=["Pass", "Fail"], autopct = "%2.4f%%")
plt.title("AVERAGE PASS PERCENTAGE")
plt.ylabel("ToTal")
plt.show()

plt.figure(figsize=(5,10))
sns.histplot(df["G2"], kde=True, bins=30, color="green")
plt.show()

plt.subplots(5,10, figsize=(10,15))
df.boxplot(column="absences", by="G2")
plt.xlabel("Students")
plt.ylabel("Rate")
plt.show()

#df.corr(numeric_only=True) is used convert only numeric data into matrix as heatmap only accepts 2d data

plt.figure(figsize=(10,15))
sns.heatmap(df.corr(numeric_only=True), annot=True,fmt=".2f", cmap="rainbow")
plt.show()

sns.barplot(x=df["absences"], y = df["G2"], data=df)
plt.show()




